@echo off
chcp 65001 >nul
setlocal EnableExtensions

rem ==============================================================
rem Elevate to administrator (UAC) if not already elevated
rem ==============================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Requesting administrative privileges...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

rem ==============================================================
rem Paths
rem ==============================================================
set "BASEDIR=%~dp0"
set "SRC_DIR=%BASEDIR%PopupKiller"
set "DST_DIR=C:\LXNC\LXData\VisualScreen\Setting\SSC_Accessories\PopupKiller"
set "STARTUP=C:\Users\MAZATROL\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup"

rem ==============================================================
rem Copy PopupKiller folder
rem ==============================================================
if not exist "%DST_DIR%" (
    mkdir "%DST_DIR%"
)

xcopy "%SRC_DIR%" "%DST_DIR%" /E /I /Y

rem ==============================================================
rem Create Startup shortcut
rem ==============================================================
if not exist "%STARTUP%" (
    mkdir "%STARTUP%"
)

set "VBS=%TEMP%\mkshortcut_%RANDOM%.vbs"
> "%VBS%" echo Set oWS = CreateObject("WScript.Shell")
>>"%VBS%" echo Set lnk = oWS.CreateShortcut(WScript.Arguments(0))
>>"%VBS%" echo lnk.TargetPath = WScript.Arguments(1)
>>"%VBS%" echo lnk.WorkingDirectory = WScript.Arguments(2)
>>"%VBS%" echo lnk.IconLocation = WScript.Arguments(3)
>>"%VBS%" echo lnk.Save

del /q "%STARTUP%\PopupKiller.lnk" 2>nul

cscript //nologo "%VBS%" ^
 "%STARTUP%\PopupKiller.lnk" ^
 "%DST_DIR%\PopupKiller.exe" ^
 "%DST_DIR%" ^
 "%DST_DIR%\PopupKiller.exe,0"

del /q "%VBS%" 2>nul
rem ==============================================================
rem Auto-close this console after 5 seconds
rem ==============================================================
echo ============================================
echo Processing, please wait...
echo Setting up the system...
echo ============================================
timeout /t 5 /nobreak >nul

exit